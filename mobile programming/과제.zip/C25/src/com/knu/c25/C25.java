package com.knu.c25;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class C25 extends Activity implements OnClickListener {
EditText a;
Button b;
TextView c;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		a=(EditText) findViewById(R.id.a_edt);
		b=(Button) findViewById(R.id.a_btn);
		c=(TextView) findViewById(R.id.a_txt);
		b.setOnClickListener(this);
	}
	public void onClick(View arg0) {
		int d,e,f;
		e=0;
		f=0;
		String tmp="";
		tmp= a.getText().toString(); 
		for (d=Integer.parseInt(tmp);d<=100; d++)
		{
			if(d%2==1)
				e+=d;
			else
				f+=d;
			}
			tmp=String.format("Ȧ����=%d,¦����=%d\n",e,f);
			c.setText(tmp);
	}
}