package com.knu.c17;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class C17 extends Activity implements OnClickListener {
TextView a;
EditText b;
Button c;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	a=(TextView) findViewById(R.id.a_Txt);
	b=(EditText) findViewById(R.id.a_Edt);
	c=(Button) findViewById(R.id.b_Btn);
	c.setOnClickListener(this);
	
	}
	public void onClick(View arg0) {
		String tmp="";
		tmp= b.getText().toString();
		a.setText("�Է��� ���ڴ�" +tmp+"�Դϴ�.");	
	}
}
