/** Automatically generated file. DO NOT MODIFY */
package com.knu.c17;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}