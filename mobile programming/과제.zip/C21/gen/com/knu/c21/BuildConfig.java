/** Automatically generated file. DO NOT MODIFY */
package com.knu.c21;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}