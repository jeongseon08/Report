/** Automatically generated file. DO NOT MODIFY */
package ciom.knu.c27;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}