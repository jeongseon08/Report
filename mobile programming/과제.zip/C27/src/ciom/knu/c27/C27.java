package ciom.knu.c27;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class C27 extends Activity implements OnClickListener {
	Button a;
	TextView b;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		a=(Button) findViewById(R.id.a_btn);
		b=(TextView) findViewById(R.id.a_txt);
		a.setOnClickListener(this);
	}

	public void onClick(View arg0) {
		hello();
	}

	private void hello() {
		
	}

	}
