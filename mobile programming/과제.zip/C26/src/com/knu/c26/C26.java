package com.knu.c26;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class C26 extends Activity implements OnClickListener {
	Button a;
	TextView b;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		a=(Button) findViewById(R.id.a_btn);
		b=(TextView) findViewById(R.id.a_txt);
		a.setOnClickListener(this);
	}
	public void onClick(View arg0) {
	int x[]= new int [10];
	int y,z;
	z=0;
	String tmp="";
	x[0]=5; //1�����迭�� ù��° ���Ҵ� ÷�ڰ� 0���� ����!
	x[1]=3;  
  	x[2]=2;
  	x[3]=7;
  	x[4]=11;
  	x[5]=15;
  	x[6]=9;
  	x[7]=10;
  	x[8]=8;
	x[9]=4;
	for (y=0; y<=9; y++)
	{
	z=z + x[y];
	}
	tmp=String.format("�迭 ������ ���� ����ϸ�%d\n",z);
	b.setText(tmp);
	}
}
