package com.knu.c18;

import com.knu.c18.R;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class C18 extends Activity implements OnClickListener {
	EditText a; 
	Button b;
	TextView c;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		setContentView(R.layout.main);
		a=(EditText) findViewById(R.id.a_edt);
		b=(Button) findViewById(R.id.b_btn);
		c=(TextView) findViewById(R.id.c_txt);
		b.setOnClickListener(this);
		
	}
	public void onClick(View arg0) {
		String tmp="";
		tmp= a.getText().toString(); 
		int d,e;
		d= Integer.parseInt(tmp);
		e=d*10-5; 
		tmp= String.valueOf(e);
		c.setText(tmp);		
	}

}
