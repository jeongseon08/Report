package com.knu.c20;
import com.knu.c20.R;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
public class C20 extends Activity implements OnClickListener {
	EditText a,b;
	Button c,d,e,f;
	TextView g;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		a=(EditText) findViewById(R.id.a_E);
		b=(EditText) findViewById(R.id.b_E);
		c=(Button) findViewById(R.id.a_B);
		d=(Button) findViewById(R.id.b_B);
		e=(Button) findViewById(R.id.c_B);
		f=(Button) findViewById(R.id.d_B);
		g=(TextView) findViewById(R.id.a_T);
		c.setOnClickListener(this);
		d.setOnClickListener(this);
		e.setOnClickListener(this);
		f.setOnClickListener(this);}
	public void onClick(View arg0) {
		String tmp="";
		String tmp2="";
		String tmp3="";
		int x,y,z;
		z=0;
		tmp =a.getText().toString();
		x=Integer.parseInt(tmp);
		tmp =b.getText().toString();
		y=Integer.parseInt(tmp);
		switch(arg0.getId())
		{
		case R.id.a_B:
			z= x+y;
			tmp2= "����";
			break;
		case R.id.b_B: 
			z= x-y;
			tmp2= "����";
			break;
		case R.id.c_B:
			z= x*y;
			tmp2= "����";
			break;
		case R.id.d_B:
			z= x/y;
			tmp2= "������";
			break;}
		tmp=String.valueOf(z);
		tmp3= String.format("%s����� %s�Դϴ�.\n", tmp2, tmp);
		g.setText(tmp3);	}
}