package com.knu.cjs23;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CJS23 extends Activity implements OnClickListener {
EditText a;
Button b;
TextView c;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
a=(EditText) findViewById(R.id.a_edt);
b=(Button) findViewById(R.id.b_btn);
c=(TextView) findViewById(R.id.c_txt);
b.setOnClickListener(this);
	}
	public void onClick(View arg0) {
		double k;
		String tmp="";
		tmp =a.getText().toString();//���� ���ڿ������� ����
		k=Integer.parseInt(tmp);
		if (k>=60)
		tmp="�հ�";
		else
			tmp="���հ�";
			c.setText(tmp);
	}
}
