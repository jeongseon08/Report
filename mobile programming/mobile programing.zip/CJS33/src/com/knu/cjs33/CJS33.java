package com.knu.cjs33;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.TextView;

public class CJS33 extends Activity implements OnTouchListener {
	TextView a,b,c,d,e,f,g,h,i;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		a=(TextView) findViewById(R.id.a2);
		b=(TextView) findViewById(R.id.a3);
		c=(TextView) findViewById(R.id.a4);
		d=(TextView) findViewById(R.id.a5);
		e=(TextView) findViewById(R.id.a6);
		f=(TextView) findViewById(R.id.a7);
		g=(TextView) findViewById(R.id.a8);
		h=(TextView) findViewById(R.id.a9);
		i=(TextView) findViewById(R.id.result);
		a.setOnTouchListener(this);
		a.setOnTouchListener(this);
		b.setOnTouchListener(this);
		c.setOnTouchListener(this);
		d.setOnTouchListener(this);
		e.setOnTouchListener(this);
		f.setOnTouchListener(this);
		g.setOnTouchListener(this);
		h.setOnTouchListener(this);
		}
	public boolean onTouch(View arg0, MotionEvent arg1) {
		int x,y; //�������� ��(1~9)�� �Ի������� ����
		String tmp="";
		y=0;
		switch(arg0.getId())
		{
		case R.id.a2://2���� ��ġ�� ���
			for(x=1;x<=9; x++)
			{
				y=2*x;
				tmp=tmp+String.format("2x%2d=%2d\n",x,y);
			}
			i.setText(tmp);
			break;
		case R.id.a3:
			for(x=1;x<=9; x++)
			{
				y=3*x;
				tmp=tmp+String.format("3x%2d=%2d\n",x,y);
			}
			i.setText(tmp);
			break;
		case R.id.a4:
			for(x=1;x<=9; x++)
			{				y=4*x;
				tmp=tmp+String.format("4x%2d=%2d\n",x,y);
			}
			i.setText(tmp);
			break;
		case R.id.a5:
			for(x=1;x<=9; x++)
			{				y=5*x;

				tmp=tmp+String.format("5x%d=%d\n",x,y);
			}
			i.setText(tmp);
			break;
		case R.id.a6://2���� ��ġ�� ���
			for(x=1;x<=9; x++)
			{				y=6*x;

				tmp=tmp+String.format("6x%d=%d\n",x,y);
			}
			i.setText(tmp);
			break;
		case R.id.a7:
			for(x=1;x<=9; x++)
			{				y=7*x;

				tmp=tmp+String.format("7x%d=%d\n",x,y);
			}
			i.setText(tmp);
			break;
		case R.id.a8:
			for(x=1;x<=9; x++)
			{				y=8*x;

				tmp=tmp+String.format("8x%d=%d\n",x,y);
			}
			i.setText(tmp);
			break;
		case R.id.a9:
			for(x=1;x<=9; x++)
			{				y=9*x;

				tmp=tmp+String.format("9x%d=%d\n",x,y);
			}
			i.setText(tmp);
			break;
		}
		return false;
		}

}
