package com.knu.cjs35;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class CJS35 extends Activity implements OnClickListener {
	Button a;
	TextView b;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		a=(Button) findViewById(R.id.a_btn);
		b=(TextView) findViewById(R.id.a_txt);
		a.setOnClickListener(this);
	}
	public void onClick(View arg0) {
	int x,y = 0,z;
	String tmp="";
	int[][] v=new int[2][3]; //2���� �迭����
	z=0;
	v[0][0]=10;
	v[0][1]=20;
	v[0][2]=30;
	v[1][0]=40;
	v[1][1]=50;
	v[1][2]=60;
	for (x=0; x<2; x++) //�ٱ� for��. �������� for��
		for(y=0; y<3; y=y+1)
			z+=v[x][y]; //������
	tmp=String.format("%d��%d���� 2�����迭��=%d\n",x,y,z);
	b.setText(tmp);
	}
}