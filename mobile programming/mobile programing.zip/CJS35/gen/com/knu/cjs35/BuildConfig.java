/** Automatically generated file. DO NOT MODIFY */
package com.knu.cjs35;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}