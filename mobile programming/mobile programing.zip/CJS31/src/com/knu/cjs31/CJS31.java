package com.knu.cjs31;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class CJS31 extends Activity implements OnClickListener {
	Button a;
	TextView b;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		a=(Button) findViewById(R.id.a_btn);
		b=(TextView) findViewById(R.id.a_txt);
		a.setOnClickListener(this);
		
	}
	public void onClick(View arg0) {
		int c,d;
		String tmp="";
		d=0;
		for (c=1;c<=100; c++)
		{
			d=c+d;
		}
	tmp= String.valueOf(d);
	b.setText(tmp); 
	}
}
