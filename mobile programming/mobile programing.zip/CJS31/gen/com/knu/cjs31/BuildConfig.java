/** Automatically generated file. DO NOT MODIFY */
package com.knu.cjs31;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}