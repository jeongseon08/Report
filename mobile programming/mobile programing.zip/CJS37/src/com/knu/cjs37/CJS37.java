package com.knu.cjs37;

import com.knu.cjs37.R;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class CJS37 extends Activity implements OnClickListener {
	Button a;
	TextView b;
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.main);
			a=(Button) findViewById(R.id.a_btn);		
			b=(TextView) findViewById(R.id.a_txt);
			a.setOnClickListener(this);
		}
		public void onClick(View arg0) {
			a(10);
		}
		private void a(int x) {
			String tmp="";
			int y,z;
			y=0;
			for(z=1;z<=x; z++)
				y=y+z;
			tmp=String.format("1����%d������ ��=%d\n",x,y);
			b.setText(tmp);
		}

	}
