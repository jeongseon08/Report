/** Automatically generated file. DO NOT MODIFY */
package com.knu.cjs2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}