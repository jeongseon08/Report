package com.knu.cjs32;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class CJS32 extends Activity implements OnClickListener {
//���������
	TextView a;
	Button b;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		a=(TextView) findViewById(R.id.a_txt);
		b=(Button) findViewById(R.id.a_btn);
		b.setOnClickListener(this);
	
	}
	public void onClick(View arg0) {
	int c,d,e;
	c=1;
	d=0;
	e=0;
	String tmp="";
	while(c<=100)
		{
		if(c%2==0)
			e+=c;
		else
			d+=c;
		c=c+1;//������!!
		}
		tmp=String.format("Ȧ����=%d,¦����=%d\n",d,e);
		a.setText(tmp);
	}
}
 